from django.apps import AppConfig


class MybotConfig(AppConfig):
    name = 'mybot'
